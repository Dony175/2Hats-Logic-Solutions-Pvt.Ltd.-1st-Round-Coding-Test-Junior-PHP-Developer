<?php

require_once "connection.php";
if(isset($_REQUEST['insert']))
{

	$name	= $_REQUEST['name'];	
	$email	= $_REQUEST['email'];	
    $address= $_REQUEST['address'];
		try
		{
			if(!isset($errorMsg))
			{
				$insert=$db->prepare('INSERT INTO user(name,email,address) VALUES(:name,:email,:address)'); 				
				$insert->bindParam(':name',$name);
				$insert->bindParam(':email',$email); 
				$insert->bindParam(':address',$address);  
					
				if($insert->execute())
				{
				
					header("location:index.php"); 
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
}
?>







<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
<title>pdo</title>
		
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<script src="js/jquery-1.12.4-jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
		
</head>

	<body>
	<div class="wrapper">
	
	<div class="container">
			
		<div class="col-lg-12">
		 
			<center><h2>Insert</h2></center>
			<form method="post" class="form-horizontal">
					
				<div class="form-group">
				<label class="col-sm-3 control-label">Name</label>
				<div class="col-sm-6">
				<input type="text" name="name" class="form-control" placeholder="enter name" />
				</div>
				</div>
						
				<div class="form-group">
				<label class="col-sm-3 control-label">Email</label>
				<div class="col-sm-6">
				<input type="text" name="email" class="form-control" placeholder="enter email" />
				</div>
				</div>
				<div class="form-group">
				<label class="col-sm-3 control-label">Address</label>
				<div class="col-sm-6">
				<input type="text" name="address" class="form-control" placeholder="enter address" />
				</div>
				</div>
			
		
				<div class="form-group">
				<div class="col-sm-offset-3 col-sm-9 m-t-15">
				<input type="submit"  name="insert" class="btn btn-success " value="Insert">
				<a href="index.php" class="btn btn-danger">Cancel</a>
				</div>
				</div>
					
			</form>
			
		</div>
		
	</div>
			
	</div>
										
	</body>
</html>