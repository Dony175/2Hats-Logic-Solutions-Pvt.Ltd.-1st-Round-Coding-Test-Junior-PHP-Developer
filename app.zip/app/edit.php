<?php

require_once "connection.php";

if(isset($_REQUEST['update_id']))
{
	try
	{
		$id = $_REQUEST['update_id']; 
		$select_stmt = $db->prepare('SELECT * FROM user WHERE id =:id'); 
		$select_stmt->bindParam(':id',$id);
		$select_stmt->execute(); 
		$row = $select_stmt->fetch(PDO::FETCH_ASSOC);
		extract($row);
	}
	catch(PDOException $e)
	{
		$e->getMessage();
	}
	
}

if(isset($_REQUEST['update']))
{
	
	$name	= $_REQUEST['name'];	
	$email	= $_REQUEST['email'];	
	$address= $_REQUEST['address'];
		
	
		try
		{
			if(!isset($errorMsg))
			{
				$update=$db->prepare('UPDATE user SET name=:name, email=:email,address=:address WHERE id=:id'); 
				$update->bindParam(':name',$name);
				$update->bindParam(':email',$email);
				$update->bindParam(':address',$address);	
				$update->bindParam(':id',$id);
				 
				if($update->execute())
				{
					header("location:index.php");
				}
			}	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}	
		
}
?>


<?php
include_once('edit1.php');
?>