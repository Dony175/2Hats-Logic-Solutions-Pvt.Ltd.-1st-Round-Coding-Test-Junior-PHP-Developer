<?php

require_once "connection.php";

if(isset($_REQUEST['delete_id']))
{
	
	$id=$_REQUEST['delete_id'];	
		
	$select_stmt= $db->prepare('SELECT * FROM user WHERE id =:id');	
	$select_stmt->bindParam(':id',$id);
	$select_stmt->execute();
	$row=$select_stmt->fetch(PDO::FETCH_ASSOC);
	$delete_stmt = $db->prepare('DELETE FROM user WHERE id =:id');
	$delete_stmt->bindParam(':id',$id);
	$delete_stmt->execute();
		
	header("Location:index.php");
}
?>
